﻿using System;

namespace TechEquipments
{
    public sealed class EquipListBoxItem
    {
        /// <summary>
        /// Service field для TreeListControl.
        /// Пока все узлы будут корневыми, но позже сюда легко добавить группы.
        /// </summary>
        public int NodeId { get; set; }

        /// <summary>
        /// Service field для TreeListControl.
        /// 0 = root node.
        /// </summary>
        public int ParentNodeId { get; set; } = 0;

        /// <summary>
        /// На первом этапе все элементы — обычное оборудование.
        /// Позже сюда можно будет добавлять synthetic group nodes.
        /// </summary>
        public bool IsGroup { get; set; }

        public string Equipment { get; init; } = "";
        public string Tag { get; init; } = "";
        public string Type { get; set; } = "";
        public string Station { get; set; } = "";

        /// <summary>
        /// Уже нормализованная группа типа. Нужна для фильтрации и для отображения значка в списке.
        /// </summary>
        public EquipTypeGroup TypeGroup { get; set; } = EquipTypeGroup.All;

        private string _description = "";
        public string Description
        {
            get => _description;
            set => _description = CleanDescription(value);
        }

        /// <summary>
        /// Текст узла для TreeListControl.
        /// Пока для equipment это просто Equipment.
        /// Позже для group nodes сюда можно отдать название группы.
        /// </summary>
        public string DisplayText => IsGroup
            ? (string.IsNullOrWhiteSpace(Description) ? Equipment : Description)
            : Equipment;

        public override string ToString() => DisplayText;

        private static string CleanDescription(string? s)
        {
            if (string.IsNullOrWhiteSpace(s))
                return "";

            s = s.Trim();

            if (s.StartsWith("@(") && s.EndsWith(")") && s.Length >= 3)
            {
                s = s.Substring(2, s.Length - 3).Trim();

                // снять кавычки, если есть
                if (s.Length >= 2 && ((s[0] == '"' && s[^1] == '"') || (s[0] == '\'' && s[^1] == '\'')))
                    s = s.Substring(1, s.Length - 2).Trim();
            }

            return s;
        }
    }
}